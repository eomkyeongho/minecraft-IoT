package pi.event;

/**
 *
 * @author Daniel Frisk, twitter:danfrisk
 */
abstract class EntityEvent {

}
